<template>
    <div>this is List</div>
</template>

<script>
export default {
    name:'List',
    beforeCreate() {
        console.log('list','beforeCreate  ===   初始化事件，收集配置项')
    },
    created() {
        console.log('list','created   ===  分配配置项到实例')
        this.bus.$on('clicks',res => {
            console.log(res)
        })
    },
    beforeMount() {
        console.log('list','beforeMount   ===   创建DOM节点前')
    },
    mounted() {
        console.log('list','mounted   ===  创建完成DOM节点')
    },
    beforeUpdate() {
         console.log('list','mounted   ===  数据改变之后')
    },
    updated() {
         console.log('list','mounted   ===  新的DOM生成之后执行')
    },
    beforeDestroy() {
        console.log('list','beforeDestroy   ===   卸载组件前')
    },
    destroyed() {
        console.log('list','Destroy   ===   卸载完成之后')
    }
}
</script>

<style>

</style>
