<template>
    <div class="home">
        this is Home
        <div @click="ToDrtail">跳转详情页</div>
    </div>
</template>

<script>
export default {
    name:'Home',
    methods: {
        ToDrtail() {
            this.$router.push('/detail/2')
        }
    }
}
</script>

<style>

</style>
