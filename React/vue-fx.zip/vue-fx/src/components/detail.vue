<template>
    <div class="detail">
        this is Detail
        <div>{{this.$route.params.id}}{{namea}}</div>
        <Dialog @detale="detale" />
    </div>
</template>

<script>
export default {
    name:'Detail',
    props:["namea"],
    components: {
        'Dialog': {
            name:'Dialog',
            template:`
                <div @click="clicks">22222</div>
            `,
            methods: {
                clicks(){
                    this.$emit('detale','7890')
                    this.$router.push('/list')
                }
            },
            beforeCreate(){
                console.log('detail','beforeCreate  ===   初始化事件，收集配置项')
            },
            created(){
                console.log('detail','created   ===  分配配置项到实例')
            },
            beforeMount(){
                console.log('detail','beforeMount   ===   创建DOM节点前')
            },
            mounted(){
                console.log('detail','mounted   ===  创建完成DOM节点')
            },
            beforeDestroy(){
                console.log('detail','beforeDestroy   ===   卸载组件前')
            },
            destroyed(){
                console.log('detail','Destroy   ===   卸载完成之后')
                //订阅在前，派发在后
                this.bus.$emit('clicks',true)
            }
        }
    },
    methods: {
        detale(val){
            console.log(val)
        }
    }
}
</script>

<style>

</style>
