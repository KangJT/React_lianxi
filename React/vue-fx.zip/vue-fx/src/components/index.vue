<template>
    <div class="index">this is Index</div>
</template>

<script>
export default {
    name:'Index'
}
</script>

<style>

</style>
