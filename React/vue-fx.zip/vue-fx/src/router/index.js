import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/components/index'
import List from '@/components/list'
import Home from '@/components/home'
import Detail from '@/components/detail'

Vue.use(Router)

export default new Router({
    routes: [{
        path: '/',
        name: 'Index',
        components: { //多个组件   出口的name与键值对应
            default: Index,
            home: Home
        }
    }, {
        path: '/Detail/:id',
        name: 'Detail',
        //props 有三种形式  Boolean值 默认为false    对象 传一些默认参数的    方法  return返回 与boolean类似
        //props:true,
        // props(){
        //     return {
        //         llll:'11111'
        //     }
        // },
        props: {
            namea: 'aoao'
        },
        component: Detail
    }, {
        path: '/List',
        name: 'List',
        component: List
    }]
})