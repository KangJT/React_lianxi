import Vue from 'vue'
import App from './App'
import router from './router'

//两种方法  挂载Vue实例    抽取Vue实例
let vm = new Vue();
Vue.prototype.bus = vm;

new Vue({
    el: '#app',
    router,
    components: { App },
    template: '<App/>'
})