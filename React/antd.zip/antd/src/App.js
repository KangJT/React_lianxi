import React, { Component } from 'react';
import "./App.css";
import {BrowserRouter as Router,Route,Link} from "react-router-dom";
import {Provider} from "react-redux";
import store from "./Elm/store/index";
import Ding from "./Elm/component/Ding";
import Find from "./Elm/component/Find";
import Index from "./Elm/component/Index";
import Detail from "./Elm/component/Detail";
class App extends Component {
  render() {
    return (
       <div>
        <Provider store={store}>
        <div className="App">
        <Router>
        <div>
         <Route path='/' exact component={Index}/>
        <Route path='/Find'  component={Find}/>
        <Route path='/Ding'  component={Ding}/>
        <Route path='/Detail'  component={Detail}/>
        </div>
      </Router>
      </div>
      </Provider>
      </div>
    
     
    );
  }
}

export default App;
