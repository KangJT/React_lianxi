import React, { Component } from 'react';
import {Link} from "react-router-dom";
class Find extends Component {
  render() {
    return (
      <div>
       <div className="wrap">
        <header className='head'>
        <input></input>
        </header>
        find
        <footer className='footer'>
        <ul>
        <Link to='/'><li>首页</li></Link>
        <Link to='/Find'><li>发现</li></Link>
        <Link to="/Ding"><li>订单</li></Link>
       </ul>
       </footer>
       </div>
      </div>
    );
  }
}

export default Find;
