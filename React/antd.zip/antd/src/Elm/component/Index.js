import React, { Component } from 'react';
import {BrowserRouter as Router,Route,Link} from "react-router-dom";
import Sy from "./Sy";
class Index extends Component {
  render() {
    return (
      <div className="App">
        <div className="wrap">
        <header className='head'>
        <input></input>
        </header>
        <Sy/>
        <footer className='footer'>
        <ul>
        <Link to='/'><li>首页</li></Link>
        <Link to='/Find'><li>发现</li></Link>
        <Link to="/Ding"><li>订单</li></Link>
       </ul>
       </footer>
       </div>
      </div>
     
    );
  }
}

export default Index;
