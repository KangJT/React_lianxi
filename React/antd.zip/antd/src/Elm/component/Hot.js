import React from "react";
class Hot extends React.Component{
    constructor(){
        super()
    }
    componentDidMount(){
   
    }
    render(){
        return(
            <div>
             hot
            </div>
        )
    }
}
export default Hot