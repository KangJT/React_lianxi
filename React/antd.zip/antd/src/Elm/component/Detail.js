import React from "react";
import "../style.css";
import Hot from "./Hot";
import Shops from "./Shops";
class Detail extends React.Component{
    constructor(){
        super()
        this.state={
            data:[],
            inds:0,
            list:[{
                    name:'热销',
                    id:0
                },{
                    name:'商品',
                    id:1
                }]
        }
    }
    shows=(ind)=>{
        this.setState({
            inds:ind
        })
    }
    componentDidMount(){
        const data = this.props.location.state;
        this.setState({
            data:data
        })
    }
    render(){
        let {list,inds} = this.state;
        return(
            <div>
                <div  className="tops">
                {list.map((val,ind)=>{
                    return( <span key={ind} onClick={()=>{this.shows(ind)}}>{val.name}</span> )
                    }) 
                }     
                </div>
                <div className="hot">
                    {inds==0?<Hot/>:''}
                </div>
                <div className="shops">
                    {inds==1?<Shops/>:''}
                </div>
            </div>
        )
    }
}
export default Detail