import React, { Component } from 'react';
import Swiper from "swiper/dist/js/swiper.js";
import "swiper/dist/css/swiper.min.css";
import {Link} from "react-router-dom";
import "../style.css";
import axios from "axios";
class Sy extends Component {
    constructor(){
        super()
        this.state={
            data:[]
        }
    }
    componentDidMount(){
        axios.get('/list').then(res=>{
            this.setState({
                data:res.data
            })
        })

        new Swiper('.swiper-container',{
            autoplay:true
        })
      }
    render() {
        let {data} = this.state;
        return (
            <div>
                <div className="swiper-container">
                    <div className="swiper-wrapper">
                        <div className="swiper-slide">
                            <img src="https://fuss10.elemecdn.com/1/9c/d8da44b63fa1208476992df88edc9jpeg.jpeg?imageMogr/format/webp/thumbnail/568x/"></img>
                        </div>
                        <div className="swiper-slide">
                            <img src="https://fuss10.elemecdn.com/1/9c/d8da44b63fa1208476992df88edc9jpeg.jpeg?imageMogr/format/webp/thumbnail/568x/"></img>
                        </div>
                    </div>
                </div>
                <div className="banner">
                {
                    data.map((val,ind)=>{
                    return(
                        <Link to={{pathname:"/Detail",state:data[0]}} key={ind}>
                            <div>
                                <p>{val.name}</p>
                            <p>
                                <img src={val.img}></img>
                            </p>
                            </div>
                        </Link>
                    )   
                    })   
                }
                </div>
            </div>
        );
    }
}

export default Sy;
