import React from "react";
import {connect} from "react-redux";
import data from "../../mock/goods.json";
import "../style.css";
class Shops extends React.Component{
    constructor(){
        super()
        this.state={
            inds:0,
            sumcount:0,
            flag:false,
            sumprice:0
        }
    }
    //初始化
    componentDidMount(){
        let {update} = this.props;
        let id=0;
        data.data.map((val,ind)=>{
            val.sum=0;
            val.id=id++;
            val.foods.map((i,j)=>{
                i.count=0;
                i.id=val.id
            })
        })
        update(data.data)
    }
    //清空购物车
    clears=()=>{
        let {list,update,prices,price,totals,total} = this.props;
        total=0;
        price=0;
        list.map((val,ind)=>{
            val.foods.map((i,j)=>{
                if(i.count>0){
                    i.count=0;
                    val.sum=0;
                }
            })
        })
        update(list);
        totals(total)
        prices(price)
        this.setState({
            flag:!this.state.flag    
        })
    }
    //判断是否显示购物车
    shows=()=>{
        this.setState({
            flag:!this.state.flag    
        })
    }
    //点击左侧列表改变下标改变背景色
    check=(ind)=>{
        this.setState({
            inds:ind
        })
    }
   //点击加减调用计算总价及总数量
    total=()=>{
        let tot = 0;
        let pric = 0;
        let {totals,list,prices} = this.props;
        list.map((val,ind)=>{
            tot+=val.sum;
            val.foods.map((i,j)=>{
                pric+=i.count*i.price;
            })
        })
        totals(tot)
        prices(pric)
    }
    //点击加号按钮
    add=(ii)=>{
        let {update,list} = this.props;
        let num = 0;
        list.map((val,ind)=>{
            val.foods.map((i,j)=>{
                //循环遍历点击加的一项数量加
                if(ii.name==i.name&&ii.id==i.id){
                    i.count++;
                }
                //点击的系列进行累加
                if(ii.id==i.id){
                    num+=i.count
                    val.sum=num;
                }
            })
        })
        this.total()
        update(list)
    }  
    //点击减号按钮
    del=(ii)=>{
        let {update,list} = this.props;
        let num = 0;
        list.map((val,ind)=>{
            val.foods.map((i,j)=>{
                if(ii.name==i.name&&ii.id==i.id){
                    i.count--;
                }
                if(ii.id==i.id){
                    num+=i.count;
                    val.sum=num;
                }
            })
        })
        this.total()
        update(list)
    }
    render(){
         let {list,total,price} = this.props;
         let {inds,flag} = this.state;
         console.log(list)
        return(
            <div className="shop-wrap">
                <div className="left">
                    {list.map((val,ind)=>{
                        return(
                            <p className={ind==inds?'active':''} key={ind} onClick={()=>{this.check(ind)}}>{val.name}
                            {val.sum>0?<span className="yuan">
                                {val.sum}
                            </span>:''}
                            </p>
                        )
                    })}
                </div>
                <div className="right">
                    { list.map((val,ind)=>{
                        if(ind==inds){
                            return(
                                val.foods.map((i,j)=>{
                                    return(
                                        <div className="cons" key={j}>
                                            <p>{i.name}</p>
                                            <p><img src={i.image}></img></p>
                                            {i.count>0?<div>
                                            <button onClick={()=>{this.add(i)}}>+</button>
                                            <b>{i.count}</b>
                                            <button onClick={()=>{this.del(i)}}>-</button>
                                            </div>: <button onClick={()=>{this.add(i)}}>+</button>}
                                        </div>
                                    )
                                })
                            )
                        }
                    })}
                </div>
                <div className="bottom">
                    数量：<span onClick={this.shows}>{total}</span>
                    价格：<b>{price}元</b>
                </div>
                {flag? <div className="shopcar">
                    <h2 onClick={this.clears}>全部清空</h2>
                    {list.map((val,ind)=>{
                        return(
                            val.foods.map((i,j)=>{
                                return(
                                    <div key={j}>
                                        {
                                        i.count>0?<div key={j}>
                                        <p>{i.name}</p>
                                        <p><img src={i.image}></img></p>
                                        <button onClick={()=>{this.add(i)}}>+</button>
                                        <b>{i.count}</b>
                                        <button onClick={()=>{this.del(i)}}>-</button>
                                        </div>:''
                                        }
                                    </div>
                                )
                            })
                        )
                    })}
                </div>:''}
            </div>
        )
    }
}
const mapStateToProps=(state)=>{
    return state.OneReducer
}
const mapDispatchToProps=(dispatch)=>{
    return{
        update(data){
            dispatch({
                type:'UPDATE',
                payload:data
            })
        },
        totals(tot){
            dispatch({
                type:'TOTAL',
                payload:tot
            })
        },
        prices(pric){
            dispatch({
                type:'PRICE',
                payload:pric
            })
        }
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Shops)