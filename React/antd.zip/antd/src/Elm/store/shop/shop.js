let InitStore = {
    list:[],
    total:0,
    price:0
}
let OneReducer = (state=InitStore,action)=>{
    let {payload,type} = action;
    switch(type){
        case 'UPDATE':
        return{
        ...state,
        list:[...payload]
        }
        case 'TOTAL':
        return{
        ...state,
        total:payload
        }
        case 'PRICE':
        return{
        ...state,
        price:payload
        }
        default :
        return state
    }
}
export default OneReducer