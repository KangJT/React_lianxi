import {createStore,combineReducers} from "redux";
import OneReducer from "./shop/shop.js";
let obj = combineReducers({
    OneReducer
})
let store = createStore(obj)
export default store